import Case from "../models/Case";
import v from "../helpers/Validation";
import { makeId } from "../helpers/String";

import { IAny, IResponse } from "../interfaces";

async function createCase(body: any, victim): Promise<IResponse> {
  try {
    const { policeStationId, description } = body;

    v.validate({
      'Description': { value: description, min: 8, max: 150 }
    });

    await Case.insert({
      case_no: makeId(5),
      police_station_id: policeStationId,
      victim_id: victim.id,
      description
    });

    this.successful = true;
  } catch (error) {
    throw error;
  }
  return this;
}

async function assignCase(body: any): Promise<IResponse> {
  try {
    const _case = await Case.findOne({
      condition: {
        case_no: body.caseNo
      }
    });

    _case.employee_id = body.employeeId;

    _case.save()

    this.successful = true;
  } catch (error) {
    throw error;
  }
  return this;
}

async function getVictimCases(body: any, victim): Promise<IResponse> {
  try {
    this.cases = await Case.find({
      condition: {
        victim_id: victim.id,
        is_deleted: false
      }
    });

    this.successful = true;
  } catch (error) {
    throw error;
  }
  return this;
}

async function getStationCases(body: any, employee): Promise<IResponse> {
  let condition = {
    police_station_id: employee.police_station_id,
    is_deleted: false
  }

  if (employee.role == 'Detective') condition['employee_id'] = employee.id;

  try {
    this.cases = await Case.find({
      condition,
      join: [
        {
          ref: 'victim',
          id: 'victim_id'
        },
        {
          kind: 'left',
          ref: 'employee',
          id: 'employee_id'
        }
      ]
    });

    this.successful = true;
  } catch (error) {
    throw error;
  }
  return this;
}

async function changeStatus(body: any): Promise<IResponse> {
  try {
    const _case = await Case.findOne({
      condition: {
        id: body.caseId
      }
    });

    _case.status = body.status;

    _case.save();

    this.successful = true;
  } catch (error) {
    throw error;
  }
  return this;
}

async function deleteCase(body: any): Promise<IResponse> {
  try {
    const { case_id } = body;

    const _case = await Case.findOne({
      condition: {
        id: case_id
      }
    });

    _case.is_deleted = true;

    _case.save()

    this.successful = true;
  } catch (error) {
    throw error;
  }
  return this;
}

export default { 
  createCase,
  assignCase,
  changeStatus,
  getVictimCases,
  getStationCases,
  deleteCase
};
