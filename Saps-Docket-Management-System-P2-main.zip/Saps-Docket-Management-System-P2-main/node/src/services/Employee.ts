import PoliceStation from "../models/PoliceStation";
import Employee from "../models/Employee";

import v from "../helpers/Validation";
import hasher from "../helpers/Hasher";
import jwt from "../helpers/Jwt";

import { IAny, IResponse } from "../interfaces";
import { removePassword, saveSession } from "./Victim";

async function createAdmin (body: IAny) {
  try {
    const { station: stationName, full_name, email, password, passwordAgain } = body;

    v.validate({
      'Police Station': { value: stationName, min: 3, max: 50 },
      'Full name': { value: full_name, min: 3, max: 50 },
      'Email address': { value: email, min: 3, max: 50 },
      'Password': { value: password, min: 8, max: 50 },
      'Password again': { value: passwordAgain, is: ['Password', 'Passwords don\'t match'] }
    });

    const station = await PoliceStation.insert({
      name: stationName
    })

    const user = await Employee.insert({
      role: 'Administrator',
      police_station_id: station.id,
      full_name,
      email,
      password: await hasher.hash(password)
    })

    saveSession.call(this, removePassword(user.toObject()));
    this.user = user.toObject()

    this.successful = true;

    return this;
  } catch (e) { throw e; }
}

async function createDetective(body: IAny, user: IAny) {
  try {
    const { full_name, email } = body;

    v.validate({
      'Full name': { value: full_name, min: 3, max: 50 },
      'Email address': { value: email, min: 3, max: 50 }
    });

    await Employee.insert({
      role: 'Detective',
      police_station_id: user.police_station_id,
      full_name,
      email,
      password: await hasher.hash('Password123')
    })

    this.successful = true;

    return this;
  } catch (e) { throw e; }
}

async function authEmployee(body: IAny) {
  try {
    const { email, password  } = body;

    v.validate({
      'Email address': { value: email, min: 3, max: 50 },
      'Password': { value: password, min: 8, max: 50 }
    });

    const user = await Employee.findOne({
      condition: { email, is_deleted: false }
    })

    if (!user || user && !(await hasher.isSame(user.password, password))) throw 'Email address or Password is incorrect';

    saveSession.call(this, removePassword(user.toObject()));
    this.user = user.toObject()

    this.successful = true;

    return this;
  } catch (e) { throw e; }
}

async function getEmployeesByStation(body: IAny, user: IAny) {
  try {
    const users = await Employee.find({
      condition: { police_station_id: user.police_station_id, is_deleted: false }
    })

    this.employees = users;

    this.successful = true;

    return this;
  } catch (e) { throw e; }
}

async function removeEmployee(body: IAny, user: IAny) {
  try {
    const users = await Employee.update({ id: body.id }, { is_deleted: true })

    this.successful = true;

    return this;
  } catch (e) { throw e; }
}

export default { createAdmin, removeEmployee, createDetective, authEmployee, getEmployeesByStation };
