import Victim from "../models/Victim";

import v from "../helpers/Validation";
import hasher from "../helpers/Hasher";
import jwt from "../helpers/Jwt";

import { IAny, IResponse } from "../interfaces";

export function saveSession(user: any) {
  const tokens = jwt.get_cookie_tokens(user);

  this.set_cookie("_dm_sesh", JSON.stringify(tokens));
}

export function removePassword(user: any) {
  delete user.password;

  return user;
}

async function createVictim (body: IAny) {
  try {
    const { full_name, email, password, passwordAgain } = body;

    v.validate({
      'Full name': { value: full_name, min: 3, max: 50 },
      'Email address': { value: email, min: 3, max: 50 },
      'Password': { value: password, min: 8, max: 50 },
      'Password again': { value: passwordAgain, is: ['Password', 'Passwords don\'t match'] }
    });

    const user = await Victim.insert({
      full_name,
      email,
      password: await hasher.hash(password)
    });

    saveSession.call(this, removePassword(user.toObject()));
    this.user = user.toObject()

    this.successful = true;
  } catch (error) {
    throw error;
  }

  return this;
}

async function authVictim (body: IAny) {
  try {
    const { email, password } = body;

    v.validate({
      'Email address': { value: email, min: 3, max: 50 },
      'Password': { value: password, min: 8, max: 50 }
    });

    const user = await Victim.findOne({ condition: { email, is_deleted: false } });

    if (!user || (user && !(await hasher.isSame(user.password, password))))
      throw "Email address or password is incorrect";

    saveSession.call(this, removePassword(user.toObject()));
    this.user = user.toObject()

    this.successful = true;
  } catch (error) {
    throw error;
  }

  return this;
}

async function updateUser(body: IAny, user: IAny) {
  try {
    const { full_name, email } = body;

    v.validate({
      'Full name': { value: full_name, min: 3, max: 50 },
      'Email address': { value: email, min: 3, max: 50 },
    });

    const _user = await Victim.findOne({ condition: { id: user.id } });

    _user.full_name = full_name;
    _user.email = email;

    _user.save()
    _user.id = _user._properties.id = user.id;

    saveSession.call(this, removePassword(_user.toObject()));

    this.user = removePassword(_user.toObject());

    this.successful = true;
  } catch (e) { throw e; }

  return this;
}

export default { createVictim, updateUser, authVictim };
