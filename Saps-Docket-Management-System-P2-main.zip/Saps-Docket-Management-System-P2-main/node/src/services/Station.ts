import PoliceStation from "../models/PoliceStation";

import { IAny, IResponse } from "../interfaces";

async function searchStations (body: IAny) {
  try {
    const { station } = body;

    if (!station) return this;

    const stations = await PoliceStation.search({
      condition: { name: station }
    })

    this.stations = stations;

    this.successful = true;

    return this;
  } catch (e) { throw e; }
}

export default { searchStations };
