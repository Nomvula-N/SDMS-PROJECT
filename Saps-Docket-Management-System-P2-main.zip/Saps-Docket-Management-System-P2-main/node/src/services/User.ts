import { IAny, IResponse } from "../interfaces";

export function getUserBySession(_, user: IAny) {
  this.user = user;

  return this;
}
