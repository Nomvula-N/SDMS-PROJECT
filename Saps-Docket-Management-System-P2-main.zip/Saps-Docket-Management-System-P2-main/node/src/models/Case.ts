import { SQLifier, SQLDate } from "sqlifier"

export default new (class _ extends SQLifier {
  constructor() {
    super();

    this.schema('case_report', {
      id: { type: 'int', isAutoIncrement: true, isPrimary: true },
      case_no: { type: 'varchar', length: 30 },
      victim_id: { type: 'int' },
      employee_id: { type: 'int' },
      police_station_id: { type: 'int' },
      description: { type: 'varchar', length: 2500 },
      status: { type: 'varchar', length: 30, default: 'pending' },
      is_deleted: { type: 'boolean', default: false },
      date_created: { type: 'datetime', default: SQLDate.now }
    })
  }
})
