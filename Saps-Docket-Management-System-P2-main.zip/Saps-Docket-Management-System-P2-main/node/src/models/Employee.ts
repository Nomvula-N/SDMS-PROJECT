import { SQLifier, SQLDate } from "sqlifier"

export default new (class _ extends SQLifier {
  constructor() {
    super();

    this.schema('employee', {
      id: { type: 'int', isAutoIncrement: true, isPrimary: true },
      role: { type: 'varchar', default: 'Detective', length: 30 },
      police_station_id: { type: 'int', ref: 'police_station' },
      full_name: { type: 'varchar', length: 30 },
      email: { type: 'varchar', length: 50 },
      password: { type: 'varchar', length: 250 },
      is_deleted: { type: 'boolean', default: false },
      date_created: { type: 'datetime', default: SQLDate.now }
    })
  }
})
