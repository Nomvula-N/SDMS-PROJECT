import { SQLifier, SQLDate } from "sqlifier"

export default new (class _ extends SQLifier {
  constructor() {
    super();

    this.schema('police_station', {
      id: { type: 'int', isAutoIncrement: true, isPrimary: true },
      name: { type: 'varchar', length: 50 },
      is_deleted: { type: 'boolean', default: false },
      date_created: { type: 'datetime', default: SQLDate.now }
    })
  }
})
