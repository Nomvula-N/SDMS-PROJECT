import { Application, Request, Response } from "express";

import BaseController from "../controllers/base";
import { getUserBySession } from "../../services/User";

export default (app: any) => {
  app.post(
    "/user/get/session",
    BaseController.wrapWithUser(getUserBySession)
  );
};
