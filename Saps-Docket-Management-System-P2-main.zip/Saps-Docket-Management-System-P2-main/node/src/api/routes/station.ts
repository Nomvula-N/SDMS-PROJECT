import { Application, Request, Response } from "express";

import BaseController from "../controllers/base";
import stationServices from "../../services/Station";

export default (app: any) => {
  app.post(
    "/stations/search",
    BaseController.wrap(stationServices.searchStations)
  );
};
