import { Application } from "express";

import userRoutes from "./user";
import victimRoutes from "./victim";
import employeeRoutes from "./employee";
import stationRoutes from "./station";
import caseRoutes from "./case";


export default (app: Application): void => {
  userRoutes(app);
  victimRoutes(app);
  employeeRoutes(app);
  stationRoutes(app);
  caseRoutes(app);
};
