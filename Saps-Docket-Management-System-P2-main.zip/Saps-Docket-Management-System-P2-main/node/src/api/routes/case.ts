import { Application, Request, Response } from "express";

import BaseController from "../controllers/base";
import caseServices from "../../services/Case";

export default (app: any) => {
  app.post(
    "/cases/create",
    BaseController.wrapWithUser(caseServices.createCase)
  );

  app.post(
    "/cases/get/by/station",
    BaseController.wrapWithUser(caseServices.getStationCases)
  );

  app.post(
    "/cases/get/by/victim",
    BaseController.wrapWithUser(caseServices.getVictimCases)
  );

  app.post(
    "/cases/assign/employee",
    BaseController.wrap(caseServices.assignCase)
  )

  app.post(
    "/cases/change/status",
    BaseController.wrap(caseServices.changeStatus)
  )

  app.post(
    "/cases/remove",
    BaseController.wrap(caseServices.deleteCase)
  )
};
