import { Application, Request, Response } from "express";

import BaseController from "../controllers/base";
import userServices from "../../services/Employee";

export default (app: any) => {
  app.post(
    "/employees/create/admin",
    BaseController.wrap(userServices.createAdmin)
  );

  app.post(
    "/employees/create/detective",
    BaseController.wrapWithUser(userServices.createDetective)
  );

  app.post(
    "/employees/remove",
    BaseController.wrapWithUser(userServices.removeEmployee)
  );

  app.post(
    "/employees/auth",
    BaseController.wrap(userServices.authEmployee)
  );

  app.post(
    "/employees/get/by/station",
    BaseController.wrapWithUser(userServices.getEmployeesByStation)
  );
};
