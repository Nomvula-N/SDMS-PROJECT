import { Application, Request, Response } from "express";

import BaseController from "../controllers/base";
import victimServices from "../../services/Victim";

export default (app: any) => {
  app.post(
    "/victims/create",
    BaseController.wrap(victimServices.createVictim)
  );

  app.post(
    "/victims/auth",
    BaseController.wrap(victimServices.authVictim)
  );

  app.post(
    "/victims/update",
    BaseController.wrapWithUser(victimServices.updateUser)
  );
};
