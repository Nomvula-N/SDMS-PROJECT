import Authenticator from "../../views/auth/Authenticator"
import Header from "../header/UserHeader"
import Sidenav from "../sidenav/User"

import "./info.css"

export default ({ children }: any) => {
  return (
    <Authenticator>
      <Header />
      <Sidenav />
      <div className="info">
        {children}
      </div>
    </Authenticator>
  )
}