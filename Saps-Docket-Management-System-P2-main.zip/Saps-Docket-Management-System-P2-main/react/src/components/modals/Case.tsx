import { closeModal } from "../../helpers/modals"
import "./modal.css"

export default (props: any) => {
  return (
    <div className="modal modal--closed" id="new-case-modal">
      <form className="modal__main" onSubmit={props.createCase}>
        <div className="modal__main__header">
          <h4>New Case</h4>
        </div>
        <div className="modal__main__body">
          <div id="case-error" className="error hide">
            <p><b>Sorry, </b><span className="error-msg"></span></p>
          </div>

          <div className="input">
            <textarea id="description" placeholder="Please give an account of what happened"></textarea>
          </div>
        </div>
        <div className="modal__main__footer flex">
          <button className="btn btn--primary margin--right-1">Report case</button>
          <button className="btn" type="button" onClick={() => closeModal('new-case')}>Cancel</button>
        </div>
      </form>
    </div>
  )
}