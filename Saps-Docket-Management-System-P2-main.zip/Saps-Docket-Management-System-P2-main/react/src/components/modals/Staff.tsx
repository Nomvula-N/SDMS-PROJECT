import { closeModal } from "../../helpers/modals"
import "./modal.css"

export default (props: any) => {
  return (
    <div className="modal modal--closed" id="new-staff-modal">
      <form className="modal__main" onSubmit={props.createEmployee}>
        <div className="modal__main__header">
          <h4>New Staff</h4>
          <p>On-board a new detective</p>
        </div>
        <div className="modal__main__body">
          <div id="staff-error" className="error hide">
            <p><b>Sorry, </b><span className="error-msg"></span></p>
          </div>

          <div className="input">
            <input type="text" id="full-name" placeholder="Full name" />
          </div>

          <div className="input margin--top-1">
            <input type="text" id="email-address" placeholder="Email address" />
          </div>
        </div>
        <div className="modal__main__footer flex">
          <button className="btn btn--primary margin--right-1">Add member</button>
          <button className="btn" type="button" onClick={() => closeModal('new-staff')}>Cancel</button>
        </div>
      </form>
    </div>
  )
}