import "./modal.css"

export default (props: any) => {
  return (
    <div className="modal" id="assign-case-modal">
      <form className="modal__main">
        <div className="modal__main__header">
          <h4>Case Assignment</h4>
          <p>Assign detectives for case: {props.targetCase}</p>
        </div>
        <div className="modal__main__body">
          <div id="case-assign-error" className="error hide">
            <p><b>Sorry, </b><span className="error-msg"></span></p>
          </div>
          {
            props.employees.map((employee: any) => (
              <p className="margin--top-1"><span className="margin--right-1" style={{ display: 'inline-block' }}>{employee.full_name}</span> <span onClick={() => props.assignCase(employee.id)}>Assign Case</span></p>
            ))
          }
        </div>
        <div className="modal__main__footer flex">
          <button className="btn" type="button" onClick={() => props.closeModal()}>Cancel</button>
        </div>
      </form>
    </div>
  )
}