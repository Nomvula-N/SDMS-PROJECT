import { Link, useNavigate } from "react-router-dom"
import "./sidenav.css"
import { postWithAuth } from "../../helpers/http"

export default () => {
  const nav = useNavigate()

  const signOut = () => {

    postWithAuth('/sign-out', {}, true)

    nav('/p/sign-in');
  }

  return (
    <div className="sidenav flex">
      <div className="sidenav__top">
        <div className="sidenav__top__item flex flex--a-center">
          <div className="sidenav__top__item__icon">
            <i className="fa fa-bars" aria-hidden="true"></i>
          </div>
          <div className="sidenav__top__item__text">
            <p>Close</p>
          </div>
        </div>

        <div className="sidenav__top__item flex flex--a-center">
          <div className="sidenav__top__item__icon">
            {/* <i className="fa fa-archive" aria-hidden="true"></i> */}
            <Link to="/p/cases">
              <i className="fa-regular fa-file-lines"></i>
            </Link>
          </div>
          <div className="sidenav__top__item__text">
            <p>Cases</p>
          </div>
        </div>

        <div className="sidenav__top__item flex flex--a-center">
          <div className="sidenav__top__item__icon">
            <Link to="/p/staff"><i className="fa-solid fa-users" aria-hidden="true"></i></Link>
          </div>
          <div className="sidenav__top__item__text">
            <p>Staff</p>
          </div>
        </div>
      </div>

      <div className="sidenav__bottom">
        <div className="sidenav__bottom__item flex flex--a-center" style={{ cursor: 'pointer' }} onClick={signOut}>
          <div className="sidenav__bottom__item__icon">
            <i className="fa fa-sign-out" aria-hidden="true"></i>
          </div>
          <div className="sidenav__bottom__item__text">
            <p>Sign out</p>
          </div>
        </div>
      </div>
    </div>
  )
}