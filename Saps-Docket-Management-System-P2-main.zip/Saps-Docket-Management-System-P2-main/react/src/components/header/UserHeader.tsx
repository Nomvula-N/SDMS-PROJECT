import { useContext } from "react"
import { AuthContext } from "../../views/auth/Authenticator"
import "./header.css"

export default () => {
  const {user} = useContext(AuthContext);

  return (
    <header className="header flex flex--a-center flex--j-space-between">
      <div className="flex flex--a-center">
        <img src="/logo/logo.png" className="margin--right-1" alt="" />
        <div>
          <p><b>Docket Management</b></p>
          <p>Cases</p>
        </div>
      </div>
      <p><b>{user.full_name}</b></p>
    </header>
  )
}