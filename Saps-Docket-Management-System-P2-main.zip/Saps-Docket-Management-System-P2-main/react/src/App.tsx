import UserSignIn from "./views/auth/UserSignIn"
import UserSignUp from "./views/auth/UserSignUp"
import UserCases from "./views/user/UserCases"
import PoliceCases from "./views/police/PoliceCases"
import Profile from "./views/user/Profile"
import PoliceSignUp from "./views/auth/PoliceSignUp"
import PoliceSignIn from "./views/auth/PoliceSignIn"
import Staff from "./views/police/Staff"
import Home from "./views/Home"

import { BrowserRouter as Router, Routes, Route } from "react-router-dom"

export default function App () {
  return (
    <Router>
      <div className="container">
        <Routes>
          <Route path="/" element={<Home />}></Route>
          <Route path="/p/sign-up" element={<PoliceSignUp />}></Route>
          <Route path="/p/sign-in" element={<PoliceSignIn />}></Route>
          <Route path="/p/cases" element={<PoliceCases />}></Route>
          <Route path="/p/staff" element={<Staff />}></Route>
          <Route path="/sign-in" element={<UserSignIn />}></Route>
          <Route path="/sign-up" element={<UserSignUp />}></Route>
          <Route path="/u/cases" element={<UserCases />}></Route>
          <Route path="/u/profile" element={<Profile />}></Route>
        </Routes>
      </div>
    </Router>
  )
}