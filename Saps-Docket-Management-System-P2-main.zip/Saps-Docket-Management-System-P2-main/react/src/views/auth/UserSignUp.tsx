import { Link, useNavigate } from "react-router-dom"
import { getValueById } from "../../helpers/dom"
import { postWithAuth, rememberUser } from "../../helpers/http"
import "./Auth.css"
import { showError } from "../../helpers/error"

export default () => {
  const nav = useNavigate();

  async function createVictim (e: any) {
    e.preventDefault();
    
    const res = await postWithAuth('/victims/create', {
      full_name: getValueById('full-name'),
      email: getValueById('email-address'),
      password: getValueById('password'),
      passwordAgain: getValueById('password-again')
    })

    if (res.successful) {
      rememberUser(res.user)
      nav('/u/cases');

      return;
    }

    showError('auth', res.error)
  }

  return (
    <div className="auth flex flex--j-center">
      <div className="auth__main">
        <div className="auth__main__header flex">
          <img src="/logo/logo.png" alt="" />
          <h1>Docket Manager</h1>
          <p>Open a case now</p>
        </div>
        <form className="auth__main__form margin--top-2" onSubmit={createVictim}>
          <div className="auth__main__form__header">
            <h4>Sign up</h4>
            <p>Create a docket</p>
          </div>
          <div className="auth__main__form__body">
            <div id="auth-error" className="error hide">
              <p><b>Sorry, </b><span className="error-msg"></span></p>
            </div>

            <div className="input">
              <input type="text" id="full-name" placeholder="Full name" />
            </div>

            <div className="input">
              <input type="email" id="email-address" placeholder="Email address"/>
            </div>

            <div className="input">
              <input type="password" id="password" placeholder="Password" />
            </div>

            <div className="input">
              <input type="password" id="password-again" placeholder="Password confirmation" />
            </div>
          </div>
          <div className="auth__main__form__footer">
            <button className="btn btn--primary">Sign in.</button>
          </div>
        </form>
        <div className="auth__main__footer margin--top-1 flex flex--j-space-around">
          <p>Have an account? <Link to="/sign-in">Sign in instead</Link></p>
          <p>Privacy Policy</p>
        </div>
      </div>
    </div>
  )
}