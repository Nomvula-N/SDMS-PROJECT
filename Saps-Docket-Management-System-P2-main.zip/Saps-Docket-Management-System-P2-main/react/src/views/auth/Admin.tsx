import { useContext } from "react"
import { AuthContext } from "./Authenticator"

export default (props: any) => {
  const { user } = useContext(AuthContext);

  return (
    user.role == `Administrator` ? props.children : <></>
  )
}