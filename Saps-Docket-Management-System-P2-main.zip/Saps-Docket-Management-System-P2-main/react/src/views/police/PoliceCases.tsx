import { useEffect, useState } from "react";
import PoliceManager from "../../components/info/PoliceManager"
import { postWithAuth } from "../../helpers/http";
import { formatTime } from "../../helpers/date";
import Admin from "../auth/Admin";
import Assign from "../../components/modals/Assign";
import Detective from "../auth/Detective";

export default () => {
  const [cases, setCases] = useState([]) as any;
  const [targetCase, setTargetCase] = useState('');
  const [employees, setEmployees] = useState([]) as any;

  async function getCases() {
    const res = await postWithAuth('/cases/get/by/station', {});

    return res.cases;
  }

  async function getEmployees() {
    const res = await postWithAuth('/employees/get/by/station', {});

    return res.employees;
  }

  async function assignCase(employeeId: string) {
    await postWithAuth('/cases/assign/employee', {
      employeeId,
      caseNo: targetCase
    });

    setCases(await getCases())
    setTargetCase('')
  }

  async function changeStatus (caseId: string, status: string) {
    await postWithAuth('/cases/change/status', {
      caseId,
      status
    });

    setCases(await getCases())
  }

  function closeModal () {
    setTargetCase('')
  }

  useEffect(() => {
    (async () => {
      setCases(await getCases())
      setEmployees(await getEmployees())
    })()
  }, [])

  return (
    <PoliceManager>
      <div className="info__page-heading">
        <h1>Received Cases</h1>
        <p>Update progress report</p>
      </div>

      <div className="info__padded">
        <table className="info__table">
          <thead>
            <tr>
              <th>Case no</th>
              <th>Victim</th>
              <th>Description</th>
              <th>Status</th>
              <th>Date Opened</th>
              <Admin>
                <th>Detective</th>
              </Admin>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {cases &&
              cases?.map((_case: any) => (
                <tr key={_case.id}>
                  <td>{_case.case_no}</td>
                  <td>{_case.full_name}</td>
                  <td>{_case.description}</td>
                  <td>{_case.status}</td>
                  <td>{formatTime(new Date(_case.date_created))}</td>
                  <Admin>
                    <td>{_case._employee_full_name ? _case._employee_full_name : 'Not Assigned'}</td>
                    <td onClick={() => setTargetCase(_case.case_no)}><i className="fa-solid fa-share"></i></td>
                  </Admin>
                  <Detective>
                    {
                      _case.status == 'pending' ? 
                        (<td onClick={() => changeStatus(_case.id, 'Investigating')}>Begin investigation</td>) :
                        (
                          _case.status == 'Investigating' ?
                            (<td onClick={() => changeStatus(_case.id, 'Investigation done')}>Complete investigation</td>) :
                            (<td>Investigation Complete</td>)
                        )
                    }
                  </Detective>
                </tr>
              ))
            }
          </tbody>
        </table>
      </div>

      {
        targetCase && <Assign assignCase={assignCase} closeModal={closeModal} targetCase={targetCase} employees={employees} />
      }

    </PoliceManager>
  )
}