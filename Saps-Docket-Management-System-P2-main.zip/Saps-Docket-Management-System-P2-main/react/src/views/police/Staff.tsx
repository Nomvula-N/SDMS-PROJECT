import { useEffect, useState } from "react";
import PoliceManager from "../../components/info/PoliceManager"
import { postWithAuth } from "../../helpers/http";
import { formatTime } from "../../helpers/date";
import Admin from "../auth/Admin";
import Staff from "../../components/modals/Staff";
import { getValueById } from "../../helpers/dom";
import { closeModal, openModal } from "../../helpers/modals";

export default () => {
  const [employees, setEmployees] = useState([]) as any;

  async function getEmployees() {
    const res = await postWithAuth('/employees/get/by/station', {});

    return res.employees;
  }

  async function removeEmployee (employeeId: string) {
    const res = await postWithAuth('/employees/remove', {
      id: employeeId
    });

    if (res.successful) {
      setEmployees(await getEmployees())
    }
  }

  async function createEmployee (e: any) {
    e.preventDefault();

    const res = await postWithAuth('/employees/create/detective', {
      full_name: getValueById('full-name'),
      email: getValueById('email-address')
    });
    
    if (res.successful) {
      setEmployees(await getEmployees())

      closeModal('new-staff')

      return;
    }
  }

  useEffect(() => {
    (async () => {
      setEmployees(await getEmployees())
    })()
  }, [])

  return (
    <PoliceManager>
      <div className="info__page-heading">
        <h1>Police station Staff</h1>
        <p>Police station staff</p>
      </div>

      <div className="info__padded">
        <table className="info__table">
          <thead>
            <tr>
              <th>Full name</th>
              <th>Email address</th>
              <th>Onboard date</th>
              <Admin>
                <th>Actions</th>
              </Admin>
            </tr>
          </thead>
          <tbody>
            {employees &&
              employees?.map((employee: any) => (
                <tr key={employee.id}>
                  <td>{employee.full_name}</td>
                  <td>{employee.email}</td>
                  <td>{formatTime(new Date(employee.date_created))}</td>
                  <Admin>
                    <td>
                      <span><i className="fa-solid fa-pen"></i></span>
                      {
                        employee.role == 'Detective' && (
                          <span style={{ marginLeft: '1.4rem' }} onClick={() => removeEmployee(employee.id)}><i className="fa-solid fa-trash"></i></span>
                        )
                      }
                    </td>
                  </Admin>
                </tr>
              ))
            }
          </tbody>
        </table>
        <Admin>
          <button onClick={() => openModal('new-staff')} className="btn btn--primary margin--top-2">Add detective</button>
        </Admin>
      </div>

      <Admin>
        <Staff createEmployee={createEmployee}/>
      </Admin>

    </PoliceManager>
  )
}