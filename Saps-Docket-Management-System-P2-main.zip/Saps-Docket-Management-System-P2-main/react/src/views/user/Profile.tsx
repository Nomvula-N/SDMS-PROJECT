import { useContext } from "react"
import UserManager from "../../components/info/UserManager"
import { getValueById } from "../../helpers/dom"
import { postWithAuth, rememberUser } from "../../helpers/http"

import "./Profile.css"
import { AuthContext } from "../auth/Authenticator"

export default () => {
  async function updateUser (e: any) {
    e.preventDefault();

    const res = await postWithAuth('/victims/update', {
      full_name: getValueById('fullname'),
      email: getValueById('email')
    }, true)

    rememberUser(res.user);

    location.reload()
  }

  return (
    <UserManager>
      <div className="info__page-heading">
        <h1>Profile</h1>
        <p>Manage your personal info</p>
      </div>

      <div className="info__padded">
        <div className="profile flex">
          <div className="profile__overview flex">
            <ProfileDetails/>
          </div>
          <form className="profile__details" onSubmit={updateUser}>
            <VictimForm/>
            <button className="btn btn--primary margin--top-2">Update</button>
          </form>
        </div>
      </div>

    </UserManager>
  )
}

function ProfileDetails () {
  const { user } = useContext(AuthContext)

  return (
    <>
      <div className="profile__overview__photo image--back image--round" style={{ backgroundImage: "url('/profile/blank.jpg')" }}></div>
      <h4>{user?.full_name}</h4>
      <p>{user?.email}</p>
    </>
  )
}

function VictimForm () {
  const { user } = useContext(AuthContext)

  return (
    <>
      <div className="input">
        <input type="text" id="fullname" defaultValue={user?.full_name} placeholder="Full name" />
      </div>
      <div className="input margin--top-1">
        <input type="email" id="email" defaultValue={user?.email} placeholder="Email address" />
      </div>
    </>
  )
}