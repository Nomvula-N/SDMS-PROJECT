import { useEffect, useState } from "react";
import UserManager from "../../components/info/UserManager"
import Case from "../../components/modals/Case"
import { postWithAuth } from "../../helpers/http";
import { closeModal, openModal } from "../../helpers/modals"
import { getValueById } from "../../helpers/dom";
import { formatTime } from "../../helpers/date";

export default () => {
  const [stations, setStations] = useState([]) as any;
  const [cases, setCases] = useState([]) as any;
  const [policeStationId, setPoliceStationId] = useState([]) as any;

  async function getCases () {
    const res = await postWithAuth('/cases/get/by/victim', {});

    return res.cases; 
  }

  useEffect(() => {
    (async () => {
      setCases(await getCases())
    })()
  }, [])

  async function createCase(e: any) {
    e.preventDefault();

    const res = await postWithAuth('/cases/create', {
      policeStationId,
      description: getValueById('description')
    })

    setCases(await getCases())

    if (res.successful) closeModal('new-case')
  }

  async function searchStations () {
    const res = await postWithAuth('/stations/search', {
      station: getValueById('station-name')
    })

    setStations(res.stations)
  }

  async function openCase (_policeStationId: string) {
    setPoliceStationId(_policeStationId)

    openModal('new-case');
  }

  async function removeCase(case_id: string) {
    await postWithAuth('/cases/remove', {
      case_id
    })

    setCases(await getCases()) 
  }

  return (
    <UserManager>
      <div className="info__page-heading">
        <h1>Cases</h1>
        <p>Report a case</p>
      </div>

      <div className="info__padded">
        <div className="search">
          <div className="input">
            <input type="text" id="station-name" onChange={searchStations} placeholder="Search Police Station ..." />
          </div>
          {stations && stations.length > 0 && (
            <table className="info__table" style={{ marginTop: '4rem' }}>
              <tbody>
                {stations?.map((station: any) => (
                  <tr>
                    <td>{station.name}</td>
                    <td onClick={() => openCase(station.id)}>Open Case</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        <table className="info__table" style={{ marginTop: '4rem' }}>
          <thead>
            <tr>
              <th>Case no</th>
              <th>Description</th>
              <th>Status</th>
              <th>Date Opened</th>
              <th>...</th>
            </tr>
          </thead>
          <tbody>
            {cases && 
              cases?.map((_case: any) => (
                <tr key={_case.id}>
                  <td>{_case.case_no}</td>
                  <td>{_case.description}</td>
                  <td>{_case.status}</td>
                  <td>{formatTime(new Date(_case.date_created))}</td>
                  <td style={{ color: 'darkred', cursor: 'pointer' }} onClick={() => removeCase(_case.id)}>Remove</td>
                </tr>
              ))
            }
          </tbody>
        </table>
      </div>

      <Case createCase={createCase}/>

    </UserManager>
  )
}